# -*- coding: utf-8 -*-
"""
Created on Sun Dec  5 17:44:13 2021

@author: Neptune
"""

import pygame as pg
import map_data

class DATA:
    #record all fixed data
    
    #set screen size，whether full screen，color display depth
    #this game has 20*10 grids, each grid contains 60*60 pixels
    SCREEN_WIDTH=1200              
    SCREEN_HEIGHT=600
    SCREEN_FLAG=0    #flag 0 for windows status, flags=pg.FULLSCREEN for fullscreen
    SCREEN_IMG_BIT=32 #color display depth，normally default is the best
    #set game title
    GAME_TITLE='DINOSAUR ARENA'
    ##screeb refrash rate, used to control game speed
    fps=24
    #obstacles images
    OBS_IMAGES=[
        pg.image.load(r"./img/other/wall_1.png"),
        pg.image.load(r"./img/other/wall_06.png"),
        pg.image.load(r"./img/other/lava.png"),
        ]
    
    #import maps from file map_data          
    MAPS=map_data.maps
    
    #0 nothing everything can pass it               
    #1steel both dinosaurs and bullets(here is flame from dinasaurs) can't get through steels
    #2 bricks  : can be destroyed by bullet to be set to noting
    #3 lava : dinosaurs can not step onto lava but flame can pass it
    
    #Blank map, this contains 12*22 grids, but dinasaus could only move in 10*20 grids
    #cause we do not want our dinasaurs leave screen and we do not want to print the outside wall of the map
    MAP_1=[          
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]            

    
    #draw the map
    def draw_map(screen):
        # y represents the number of grid in y axis
        for y in range(1,len(DATA.MAP_1)-1):
           for x in range(1,len(DATA.MAP_1[y])-1):
               #-1 is because we do not want to print the outside wall of the map
               index_y = y-1
               index_x = x-1
               #get the x and y ,then transform to pixel coordinate
               pos_x=index_x*60
               pos_y=index_y*60
               #Traversing the list to set up image in each grid
               if DATA.MAP_1[y][x]!=0:
                   if DATA.MAP_1[y][x]==1:
                       obs_x=DATA.OBS_IMAGES[0]
                   elif DATA.MAP_1[y][x]==2:
                       obs_x=DATA.OBS_IMAGES[1]
                   elif DATA.MAP_1[y][x]==3:
                       obs_x=DATA.OBS_IMAGES[2]
                   elif DATA.MAP_1[y][x]==4:
                       obs_x=DATA.OBS_IMAGES[3]
                   screen.blit(obs_x,(pos_x,pos_y))
                                 
def update_map(gameround):          # updata the information of MAP_1 with a different address
        for i in range (0,len(map_data.maps[gameround])):
            for j in range(0,len(map_data.maps[gameround][i])):
                DATA.MAP_1[i][j]=map_data.maps[gameround][i][j]
#%%

