import pygame as pg
import boyi
#creat start interface
def start_interface(screen):
    #load images
    background = pg.image.load(r"img/other/start_bk.png")
    startBtn = pg.image.load(r"img/other/start_btn_03.png")
    screen_rect = screen.get_rect()
    #blit screen and images in the screen
    screen.blit(background, (0, 0))
    #blit start button images
    screen.blit(startBtn, (screen_rect.centerx - 42, 450))
    #screen update
    pg.display.update()  
    
    rect1 = startBtn.get_rect()#get the start button width and height
    flag = True #flag to control if loop

    while True:
        #use it to control start button flash speed
        pg.time.wait(400)
        if(flag):
            screen.blit(background, (0, 0))
            flag = False
            pg.display.update()  
        else:
            screen.blit(startBtn, (screen_rect.centerx - 42, 450))
            flag =True
            pg.display.update()  
        #if click the start buttion will return 1 which will be used to start the game
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                return 0
            elif event.type == pg.MOUSEBUTTONDOWN:
                pos_x, pos_y = event.pos
                #judge the mouse position
                if screen_rect.centerx-rect1.width/2<=pos_x<screen_rect.centerx+rect1.width/2 and 450<=pos_y<450+rect1.height:
                    return 1

#loop_loose function, we will use it when lose the round game 
def loop_lose(a,flag,screen):
    while True:
        #load dead scene background, backhome and resurrect iamges
        end_background = pg.image.load("./img/other/end_background.png")
        screen.blit(end_background,[0,0])
        
        backhome = pg.image.load("./img/other/backhome.png")
        screen.blit(backhome,[200,400])#blit and set up this iamge location
        resurrect = pg.image.load("./img/other/resurrect.png")
        screen.blit(resurrect,[800,400])#blit and set up this iamge location
        
        e=pg.event.poll()
        if e.type==pg.QUIT:#if we get the QUIT command it will quit  and return false
            pg.quit()
            return False
        if e.type == pg.MOUSEBUTTONUP:
            
                x, y = e.pos
                # to judage if the mouse location collide with backhome image
                if pg.Rect(200,400,258,72).collidepoint(e.pos): 
                    print("go back home")
                    return #if true we will return

               #if click the resurrtext, it will move to the gaming theory game
                if pg.Rect(800,400,258,72).collidepoint(e.pos):
                    print("do resurrext")
                    ttt=boyi.boyi(screen,a,flag) #call boyi function(gaming theory game)
                    if ttt!=-1:
                        screen=pg.display.set_mode((1200,600))
                    if not ttt==False:
                        flag[ttt//10-1]=ttt%10
                        break 
        pg.display.flip() #flip the screen in each while loop
    return True

#loop_win function, we will use it when win the round game 
def loop_win(gameround,screen):#two paras, one is to control game round.
    while True:
        #load dead scene background and button iamges and blit them in fixed loaction
        win_end = pg.image.load("./img/other/win_end.png")
        screen.blit(win_end,[0,0])
        backhome = pg.image.load("./img/other/backhome.png")
        screen.blit(backhome,[800,400])
        nextround = pg.image.load("./img/other/next_round.png")
        if gameround<1:
            screen.blit(nextround,[200,400])          
        #create a object e which get event from event polll
        e=pg.event.poll()
        if e.type==pg.QUIT:#if we get the QUIT command it will quit loop and return false
            pg.quit()
            break
        #if palyer click the next round, it will go next round by using gameround
        if e.type == pg.MOUSEBUTTONUP: 
            if pg.Rect(200,400,258,72).collidepoint(e.pos) and gameround<1:
                print("next round")
                gameround += 1
                return gameround
        #if palyer click goback home, it will go back to homepage        
        if e.type == pg.MOUSEBUTTONUP:
                x, y = e.pos
                if pg.Rect(800,400,258,72).collidepoint(e.pos):
                    print("go back home")
                    return 0
        #update screen for each while loop
        pg.display.flip()