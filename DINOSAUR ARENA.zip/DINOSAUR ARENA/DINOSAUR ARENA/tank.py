# -*- coding: utf-8 -*-
"""
Created on Sun Dec  5 22:04:40 2021

@author: liuxx
"""
ms = 60                         # size of map
#############################################################################
#                                                                           #
#   tank.num is a flag to show the enemy, 0 is player, 1 is enemy           #
#                                                                           #
#   tank.pos is the position, could be a list.                              #
#                                                                           #
#   tank.direction is direction of tank.                                    #
#     tank.direction=0 means up                                             #
#     tank.direction=1 means down                                           #
#     tank.direction=0 means left                                           #
#     tank.direction=0 means right                                          #
#                                                                           #
#   screen and mapp are included because tank will undate the screen and    #
#   visit the information in mapp                                           #
#                                                                           #
############################################################################# 
import pygame as pg
from bullet import Bullet

class tank:
    def __init__(self, number, pos, direction,screen,mapp):
        self.num = number
        self.img = pg.image.load(r"./img/dragon/0010.png")
        self.speed = 5
        self.hp = 30
        self.pos = pos
        self.size = 50
        self.direction = direction
        self.screen=screen
        self.bullet = Bullet(screen,mapp)
        self.mapp=mapp
        

    def point(self):                            # return the point of 4 corners
        return [(self.pos[0], self.pos[1]), (self.pos[0] + self.size, self.pos[1]),(self.pos[0], self.pos[1] + self.size), (self.pos[0] + self.size, self.pos[1] + self.size)]

    def move_up(self):                          # move_up
        self.pos[1] -= self.speed

    def move_down(self):                        # move_down
        self.pos[1] += self.speed

    def move_left(self):                        # move_left
        self.pos[0] -= self.speed

    def move_right(self):                       # move_right
        self.pos[0] += self.speed

    def shoot(self):                            # attack
        
        self.bullet.being = True
        self.bullet.turn(self.direction)        # get direction
        if self.direction == 1:                             # get the initial position of bullet
            self.bullet.rect.left = self.pos[0] + 18
            self.bullet.rect.bottom = self.pos[1] + 50
        elif self.direction == 0:
            self.bullet.rect.left = self.pos[0] + 18
            self.bullet.rect.top = self.pos[1]
        elif self.direction == 3:
            self.bullet.rect.right = self.pos[0] + 50
            self.bullet.rect.top = self.pos[1] + 18
        elif self.direction == 2:
            self.bullet.rect.left = self.pos[0]
            self.bullet.rect.top = self.pos[1] + 18
        else:
            raise ValueError('myTank class -> direction value error.')

    def judge(self, pont, enemy, direction):    # check if tank crash an enemy
        for i in enemy:
            if direction == 0 and (pg.Rect(i.pos[0], i.pos[1], i.size, i.size).collidepoint(pont[0][0], pont[0][1]) or pg.Rect(i.pos[0],i.pos[1],i.size,i.size).collidepoint(pont[1][0], pont[1][1])):
                return False
            if direction == 1 and (pg.Rect(i.pos[0], i.pos[1], i.size, i.size).collidepoint(pont[2][0], pont[2][1]) or pg.Rect(i.pos[0],i.pos[1],i.size,i.size).collidepoint(pont[3][0], pont[3][1])):
                return False
            if direction == 2 and (pg.Rect(i.pos[0], i.pos[1], i.size, i.size).collidepoint(pont[0][0], pont[0][1]) or pg.Rect(i.pos[0],i.pos[1],i.size,i.size).collidepoint(pont[2][0], pont[2][1])):
                return False
            if direction == 3 and (pg.Rect(i.pos[0], i.pos[1], i.size, i.size).collidepoint(pont[1][0], pont[1][1]) or pg.Rect(i.pos[0],i.pos[1],i.size,i.size).collidepoint(pont[3][0], pont[3][1])):
                return False
        return True

    def judge_wall(self,point, mapp, size, direction):      # check if tank crash a wall
        if direction == 0 and (mapp[point[0][1] // size+1][point[0][0] // size+1] >= 1 or mapp[point[1][1] // size+1][point[1][0] // size+1] >= 1):
            return False
        if direction == 1 and (mapp[point[2][1] // size+1][point[2][0] // size+1] >= 1 or mapp[point[3][1] // size+1][point[3][0] // size+1] >= 1):
            return False
        if direction == 2 and (mapp[point[0][1] // size+1][point[0][0] // size+1] >= 1 or mapp[point[2][1] // size+1][point[2][0] // size+1] >= 1):
            return False
        if direction == 3 and (mapp[point[1][1] // size+1][point[1][0] // size+1] >= 1 or mapp[point[3][1] // size+1][point[3][0] // size+1] >= 1):
            return False
        return True
    
    def self_driving(self,a):                   # let enemies moving, a is player's tank
        if self.direction==0:                   # the direction will changed following direction=(direction+1)%4
            if self.judge_wall(self.point(), self.mapp, ms, 0):
                self.move_up()
            if not self.judge_wall(self.point(), self.mapp, ms, 0):
                self.move_down()
                self.direction=(self.direction+1)%4
        if self.direction==1:
            if self.judge_wall(self.point(), self.mapp, ms, 1):
                self.move_down()
            if not self.judge_wall(self.point(), self.mapp, ms, 1):
                self.move_up()
                self.direction=(self.direction+1)%4
        if self.direction==2:
            if self.judge_wall(self.point(), self.mapp, ms, 2):
                self.move_left()
            if not self.judge_wall(self.point(), self.mapp, ms, 2):
                self.move_right()
                self.direction=(self.direction+1)%4
        if self.direction==3:
            if self.judge_wall(self.point(), self.mapp, ms, 3):
                self.move_right()
            if not self.judge_wall(self.point(), self.mapp, ms, 3):
                self.move_left()
                self.direction=(self.direction+1)%4
        if not self.bullet.being:               # enemies will keep shooting
            self.shoot()
        self.bullet.run(a)                      # the enemy of enemies is player's tank
    
    def run(self,enemy,e,cnt):                  # the operations of tanks
        if e.type == pg.QUIT:
            pg.quit()
            return
        elif pg.key.get_pressed()[pg.K_UP]:       # moving with check and change direction
            if self.judge(self.point(), enemy, 0) and self.judge_wall(self.point(), self.mapp, ms, 0):
                self.move_up()
                self.direction = 0
            if not (self.judge(self.point(), enemy, 0) and self.judge_wall(self.point(), self.mapp, ms, 0)):
                self.move_down()
    
        elif pg.key.get_pressed()[pg.K_DOWN]:     # moving with check and change direction
            if self.judge(self.point(), enemy, 1) and self.judge_wall(self.point(), self.mapp, ms, 1):
                self.move_down()
                self.direction = 1
            if not (self.judge(self.point(), enemy, 1) and self.judge_wall(self.point(), self.mapp, ms, 1)):
                self.move_up()
    
        elif pg.key.get_pressed()[pg.K_LEFT]:     # moving with check and change direction
            if self.judge(self.point(), enemy, 2) and self.judge_wall(self.point(), self.mapp, ms, 2):
                self.move_left()
                self.direction = 2
            if not (self.judge(self.point(), enemy, 2) and self.judge_wall(self.point(), self.mapp, ms, 2)):
                self.move_right()
    
        elif pg.key.get_pressed()[pg.K_RIGHT]:     # moving with check and change direction
            if self.judge(self.point(), enemy, 3) and self.judge_wall(self.point(), self.mapp, ms, 3):
                self.move_right()
                self.direction = 3
            if not (self.judge(self.point(), enemy, 3) and self.judge_wall(self.point(), self.mapp, ms, 3)):
                self.move_left()
        elif pg.key.get_pressed()[pg.K_SPACE]:     # shoot with music
            if not self.bullet.being:
                pg.mixer.music.load(r'./voice/dragonVoice.mp3')
                pg.mixer.music.play()
                self.shoot()
        
        self.img = pg.image.load(rf"./img/dragon/{self.num}{self.direction}{(self.hp)//10}{cnt}.png")
        self.screen.blit(self.img, (self.pos[0], self.pos[1]))
        for i in enemy:
            i.img = pg.image.load(rf"./img/dragon/{i.num}{i.direction}{(i.hp)//10}0.png")
            self.screen.blit(i.img, (i.pos[0], i.pos[1]))
                                                    # draw all of tanks
        self.bullet.run(enemy)                      # the enemy of player is enemies' tank
    