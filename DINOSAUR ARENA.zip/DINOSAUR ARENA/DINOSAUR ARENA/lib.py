# -*- coding: utf-8 -*-
"""
Created on Mon Dec 13 06:46:59 2021

@author: liuxx
"""
import pygame as pg


#############################################################################
#                                                                           #
#                         print a string on screen                          #
#                                                                           #
############################################################################# 
def printf(string,size,x,y,col,own):
    fontobj=pg.font.Font('font/SourceHanSansHWSC-Regular.otf', size)
    text=fontobj.render(string, True, col)
    text1=text.get_rect()
    text1.center=(x,y)
    own.blit(text, text1)
    

def output(winner,screen):                           # show 'you win' or 'you lose'
    flag=0
    while True:
        e=pg.event.poll()
        if e.type==pg.QUIT:
            pg.quit()
            break
        if e.type == pg.MOUSEBUTTONUP:
            x, y = e.pos
            if pg.Rect(420, 225, 450, 250).collidepoint(x, y):  # go back
                return flag
        pg.draw.rect(screen,pg.Color('yellow'),pg.Rect(420, 225, 450, 250))
        if winner=='ai':
            printf("You lost!",40,650,300,(200,30,20),screen)
            printf("press to go back",30,650,350,(200,30,20),screen)
            flag=0
        if winner=='player':
            printf("You win!",40,650,300,(3,230,20),screen)
            printf("press to go back",30,650,350,(200,30,20),screen)
            flag=1
        pg.display.flip()
    