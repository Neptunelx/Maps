import pygame
import mapp

class Bullet:
    def __init__(self,screen,mapp):
        self.direction = 0
        # If the address of the picture and the code are different, we have to write the complete path and add "r" in front.
        self.bullet = pygame.image.load(rf"./img/bullet/{self.direction}.png")
        # get the boundry of bullet
        self.rect = self.bullet.get_rect()
        self.rect.left, self.rect.right = 0, 0
        self.speed = 10
        # being = True means this Bullet is displayed
        self.being = False
        self.stronger = False
        self.screen=screen
        self.mapp=mapp

    def turn(self, direction):
        # turn directions
        self.direction = direction
        # [0, 1, 2, 3] means top,bottom,left,right
        if self.direction in [0,1,2,3]:
            self.bullet = pygame.image.load(rf"./img/bullet/{self.direction}.png")
        else:
            raise ValueError('Bullet class -> direction value error.')

    def move(self):
        if self.direction== 0:
            self.rect = self.rect.move(0, -self.speed)
        elif self.direction== 1:
            self.rect = self.rect.move(0, self.speed)
        elif self.direction == 2:
            self.rect = self.rect.move(-self.speed, 0)
        else:
            self.rect = self.rect.move(self.speed, 0)
        # bullet wiil vanish if the bullet move out from the scren margin
        if (self.rect.top < 3) or (self.rect.bottom > 1280 - 3) or (self.rect.left < 3) or (self.rect.right > 1280 - 3):
            self.being = False
            
    def judge_enemy(self, enemy):
        # if the left top coner of the bullet collide with the enemy's left top point, return false
        if pygame.Rect(enemy.pos[0], enemy.pos[1], enemy.size, enemy.size).collidepoint(self.rect.left, self.rect.top):
            return False
        return True

    # Determine whether the coordinate value in front of the bullet is a wall
    def judge_wall_bullet(self, point, size, direction):
        a = abs(point.left)//size+1
        b = abs(point.top) //size+1
        # A wall that cannot be broken
        if (self.mapp[b][a] == 1):
            return False
        elif (self.mapp[b][a] == 2):
            # Determine whether the coordinate value in front of the bullet is a breakable wall.
            # If yes, then break this wall
            mapp.DATA.MAP_1[b][a]=0
            return False
        return True


    def run(self,enemy):
        for each in enemy:
            # if this enemydragon is alive
            if each.hp > 0:
                # bullet hit it
                if not self.judge_enemy(each) and self.being:
                    each.hp -= 10
                    # bullet disappeared
                    self.being = False
            else:
                # dead
                enemy.remove(each)
    
        if self.being:
            # if the bullet hits the wall
            if not self.judge_wall_bullet(self.rect, 60, self.direction):
                # bullet disappeared
                self.being = False
            self.move()
            self.screen.blit(self.bullet, self.rect)


    
